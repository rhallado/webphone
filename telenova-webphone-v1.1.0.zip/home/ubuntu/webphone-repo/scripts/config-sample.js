var user = {
    //  User Name
    "User" : "sipuser",
    //  Password
    "Pass" : "yourpassword",
    //  Auth Realm
    "Realm"   : "sip.sample.com",
    // Display Name
    "Display" : "Gob Bleuth",
    // WebSocket URL
    "WSServer"  : "wss://wss.sample.com:8443"
};
